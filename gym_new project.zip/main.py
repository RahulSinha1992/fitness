from flask import Flask, render_template, redirect, request, url_for,session
from flask_mysqldb import MySQL
import MySQLdb.cursors



app = Flask(__name__)
app.secret_key = "caircocoders-ednalan-2020"

# Enter your database connection details below
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Admin12345@'
app.config['MYSQL_DB'] = 'gym_db'

# Intialize MySQL
mysql = MySQL(app)




@app.route('/')
def home():
	return render_template("index.html")



@app.route('/about')
def about():
	return render_template("about.html")
	
@app.route('/contact')
def contact():
	return render_template("contact.html")



##########  Admin Login ###################
	

@app.route('/login_admin',methods=['GET','POST'])
def adminlogin():
    msg = ''
    if request.method == 'POST': 
        username = request.form['username']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM admin WHERE username = %s AND password = %s', (username, password, ))
        nonfaclog = cursor.fetchone()
        if nonfaclog:
            # session['loggedin'] = True
            # session['id'] = nonfaclog['id']
            # session['username'] = nonfaclog['username']
            msg = 'Logged in successfully !'
            return render_template('UI/admin/admin_index.html', msg = msg)
        else:
            msg = 'Wrong Credential !'
            return render_template('login_admin.html', msg = msg)
    else:
        return render_template("login_admin.html")



###########    Admin Dashboard  #######################

@app.route('/abc')
def admin():
    return render_template("UI/admin/admin_index.html")

##########   Coach Dashboard ###############


@app.route('/coachdashboard')
def coachdashboard():
    return render_template("UI/coach/coach_index.html")

 



############   Coach_ Entry #############

@app.route("/UI/admin/coach_entry",methods=['GET','POST'])
def coach_entry():
    if request.method=='POST':
        name=request.form['name']
        mobileno=request.form['mobileno']
        email=request.form['emailid']
        state=request.form['state']
        district=request.form['district']
        experience=request.form['experience']
        username=request.form['username']
        password=request.form['password']
        cursor=mysql.connection.cursor()
        
        cursor.execute("INSERT INTO coach_entry (name,mobileno,emailid,state,district,experience,username,password) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",(name,mobileno,email,state,district,experience,username,password))
        mysql.connection.commit()
        msg="Data Inserted Successfully"
        
        return render_template("UI/admin/coach_Entry.html",msg=msg)
    else:
        cursor=mysql.connection.cursor()
        cursor.execute("SELECT * FROM coach_entry")
        coach_entry=cursor.fetchall()
        return render_template("UI/admin/coach_Entry.html",coach_entry=coach_entry)



###########   Coach Login ############



@app.route('/login_coach',methods=['GET','POST'])
def coachlogin():
    msg = ''
    if request.method == 'POST': 
        username = request.form['username']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM coach_entry WHERE username = %s AND password = %s', (username, password, ))
        coach_login = cursor.fetchone()
        if coach_login:
            session['loggedin'] = True
            session['id'] = coach_login['id']
            session['username'] = coach_login['username']
            msg = 'Logged in successfully !'
            return render_template('/UI/coach/student_Registration.html', msg = msg)
        else:
            msg = 'Wrong Credential !'
            return render_template('login_coach.html', msg = msg)
    else:
        return render_template("login_coach.html")


###########   Student Registration Form ##############


@app.route('/UI/coach/student_registration',methods=['GET','POST'])
def student_registration():
    if request.method=='POST':
        first_name=request.form['first_name']
        last_name=request.form['last_name']
        gender=request.form['gender']
        age=request.form['age']
        height=request.form['height']
        weight=request.form['weight']
        bmi=request.form['bmi']
        cursor=mysql.connection.cursor()
        cursor.execute("INSERT INTO student_registration (first_name,last_name,gender,age,height,weight,bmi) VALUES (%s,%s,%s,%s,%s,%s,%s)",(first_name,last_name,gender,age,height,weight,bmi))
        mysql.connection.commit()
        msg="Data Inserted Successfully"
        
        return render_template("UI/coach/student_Registration.html",msg=msg)
    else:
        cursor=mysql.connection.cursor()
        cursor.execute("SELECT * FROM student_registration")
        student_registration=cursor.fetchall()
        return render_template("UI/coach/student_Registration.html",student_registration=student_registration)



    





    
        

        
        


if __name__ == '__main__':
	app.run(debug=True)
